

1. Descarga la ISO de Arch Linux Oficial.
2. Descargar el Script y ejecutalo.

# Como descargar el instalador en la ISO

> Método 1
```
loadkeys es
curl -L is.gd/arch > arch ; sh arch
```

> Método 2
```
loadkeys es
pacman -Sy wget --noconfirm
wget is.gd/arch ; sh arch
```


